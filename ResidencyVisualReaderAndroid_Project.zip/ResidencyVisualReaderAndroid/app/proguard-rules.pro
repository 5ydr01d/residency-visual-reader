# The HTML reader is stored in app/src/main/assets/index.html.
# No custom shrinker rules are needed while minification is disabled.
