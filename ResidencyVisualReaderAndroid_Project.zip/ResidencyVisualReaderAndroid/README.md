# Residency Visual Reader — Android project

This project wraps the self-contained visual study reader in a dedicated Android app. The complete HTML is bundled at `app/src/main/assets/index.html`, so the notes and controls work offline without the app requesting Internet access. External reference links are handed to the phone's browser.

## App features

- Full-screen reader area with no browser address bar.
- Portrait and landscape rotation.
- Local HTML, JavaScript, CSS and study content bundled into the APK.
- JavaScript and DOM storage enabled for reader controls/preferences.
- External reference links open in the browser.
- Back button navigates WebView history before exiting.
- No Internet permission is requested by this app.

## Build a debug APK using Android Studio (recommended)

1. Install Android Studio on a Windows, macOS or Linux computer.
2. In Android Studio's SDK Manager, install **Android SDK Platform 35** and **Android SDK Build-Tools 35.0.0**.
3. Unzip this project. In Android Studio choose **File → Open** and select the `ResidencyVisualReaderAndroid` folder (the folder containing `settings.gradle.kts`).
4. Allow Gradle sync to finish. The first build needs an Internet connection to download the Android Gradle Plugin, Gradle and AndroidX WebKit dependency; the study reader itself is offline afterward.
5. Select **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
6. After a successful build, Android Studio shows a notification with a link to the APK. The usual output path is:

   `app/build/outputs/apk/debug/app-debug.apk`

The debug APK is signed with the standard local debug key and can be installed directly on a test phone. It is not a Play Store release-signed APK.

## Build from a terminal

Use JDK 17, Gradle 8.11.1, Android SDK Platform 35 and Build-Tools 35.0.0, and make sure `ANDROID_HOME` (or `ANDROID_SDK_ROOT`) points to the SDK. From this directory run:

```bash
gradle --no-daemon assembleDebug
```

## Build an APK through GitHub Actions (optional)

The included `.github/workflows/build-apk.yml` can build the debug APK after the project is pushed to a GitHub repository. Open the repository's **Actions** tab, select **Build Residency Visual Reader APK**, choose **Run workflow**, and download the `residency-visual-reader-debug-apk` artifact when the run completes.

## Update the study content

Replace `app/src/main/assets/index.html` with the revised self-contained reader HTML, keep the filename `index.html`, then rebuild the APK. Rebuilding is required for readers who already installed an earlier version.

## Technical choices

- Package: `com.study.residencyvisualreader`
- Min SDK: Android 6.0 (API 23)
- Compile SDK: 35
- Target SDK: 34
- Android Gradle Plugin: 8.9.2
- Gradle: 8.11.1
- Java: 17
- AndroidX WebKit `WebViewAssetLoader` maps the bundled page to `https://appassets.androidplatform.net/assets/index.html`, following Android's recommended local-content loading approach: https://developer.android.com/develop/ui/views/layout/webapps/load-local-content

## Build status in this environment

The source project is prepared, but this workspace has no Android SDK, Gradle installation or network access to download those build dependencies. Therefore an APK could not be compiled or device-tested here. Build it in Android Studio or use the included GitHub Actions workflow to generate the APK.
